window.StorageService = {
  LS_KEY: 'trello-mvp-state',
  load() {
    const saved = localStorage.getItem(this.LS_KEY);
    return saved ? JSON.parse(saved) : null;
  },
  save(state) {
    localStorage.setItem(this.LS_KEY, JSON.stringify(state));
  }
};
