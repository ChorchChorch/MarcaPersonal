window.ColumnService = {
  rename(id) {
    const col = AppState.state.columns.find(c => c.id === id);
    const name = prompt('Nuevo nombre de la columna:', col.name);
    if (!name) return;
    col.name = name.trim();
    StorageService.save(AppState.state);
    Renderer.renderBoard();
  }
};
