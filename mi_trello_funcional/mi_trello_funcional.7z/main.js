window.addEventListener('DOMContentLoaded', () => {
  AppState.init();
  Modal.init();
  Renderer.renderBoard();
});
