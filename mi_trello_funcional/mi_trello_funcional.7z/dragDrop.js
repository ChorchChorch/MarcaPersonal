window.DragDropService = {
  draggedId: null,
  start(id) {
    this.draggedId = id;
  },
  drop(targetColumnId) {
    const card = AppState.state.cards.find(c => c.id === this.draggedId);
    if (card) {
      card.columnId = targetColumnId;
      StorageService.save(AppState.state);
      Renderer.renderBoard();
    }
    this.draggedId = null;
  }
};
