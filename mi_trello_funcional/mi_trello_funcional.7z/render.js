// render.js

window.Renderer = {
  renderBoard() {
    const board = document.getElementById('board');
    if (!board) {
      console.warn("No se encontró el contenedor #board");
      return;
    }

    board.innerHTML = '';

    try {
      AppState.state.columns.forEach(col => {
        if (!col || typeof col.name !== 'string') return;

        const colEl = document.createElement('div');
        colEl.className = 'column';

        // Cabecera de columna
        const header = document.createElement('div');
        header.className = 'column-header';

        const title = document.createElement('span');
        title.textContent = col.name;

        const renameBtn = document.createElement('button');
        renameBtn.textContent = '✎';
        renameBtn.title = 'Renombrar columna';
        renameBtn.onclick = () => ColumnService.rename(col.id);

        header.append(title, renameBtn);
        colEl.append(header);

        // Contenedor de tarjetas
        const cardsEl = document.createElement('div');
        cardsEl.className = 'cards';
        cardsEl.ondragover = e => e.preventDefault();
        cardsEl.ondrop = e => {
          e.preventDefault();
          DragDropService.drop(col.id);
        };

        const cards = AppState.state.cards.filter(c => c.columnId === col.id);
        cards.forEach(c => {
          if (!c || typeof c.title !== 'string') return;

          const cardEl = document.createElement('div');
          cardEl.className = 'card';
          cardEl.draggable = true;
          cardEl.style.borderColor = c.color || '#999';
          cardEl.ondragstart = () => DragDropService.start(c.id);
          cardEl.ondblclick = () => Modal.open(col.id, c); // 👈 Doble clic abre modal

          // Encabezado de tarjeta
          const cardHeader = document.createElement('div');
          cardHeader.className = 'card-header';

          const titleSpan = document.createElement('span');
          titleSpan.textContent = c.title;
          titleSpan.style.color = c.color || '#333'; // Título coloreado

          const actions = document.createElement('div');

          const editBtn = document.createElement('button');
          editBtn.textContent = '✎';
          editBtn.onclick = () => Modal.open(col.id, c);

          const deleteBtn = document.createElement('button');
          deleteBtn.textContent = '🗑';
          deleteBtn.onclick = () => {
            CardService.delete(c.id);
            StorageService.save(AppState.state);
            Renderer.renderBoard();
          };

          actions.append(editBtn, deleteBtn);
          cardHeader.append(titleSpan, actions);
          cardEl.append(cardHeader);

          // Descripción segura (sin markdown)
          const desc = document.createElement('div');
          const rawText = typeof c.description === 'string' ? c.description : '';
          desc.textContent = rawText;
          cardEl.append(desc);

          cardsEl.append(cardEl);
        });

        colEl.append(cardsEl);

        // Botón para agregar tarjeta
        const addBtn = document.createElement('div');
        addBtn.className = 'add-card';
        addBtn.textContent = '+ Carta';
        addBtn.onclick = () => Modal.open(col.id);
        colEl.append(addBtn);

        board.append(colEl);
      });
    } catch (err) {
      console.error("Error durante renderBoard:", err);
      board.innerHTML = '<div style="padding:20px;color:red;">⚠️ Ocurrió un error al cargar el tablero.</div>';
    }
  }
};
