window.Modal = {
  activeCol: null,
  editingCard: null,
  init() {
    this.modal = document.getElementById('card-modal');
    this.form  = document.getElementById('card-form');
    this.title = document.getElementById('card-title');
    this.color = document.getElementById('card-color');
    this.desc  = document.getElementById('card-description');
    this.head  = document.getElementById('modal-title');
    this.cancel= document.getElementById('card-cancel');

    this.form.addEventListener('submit', e => this.onSubmit(e));
    this.cancel.addEventListener('click', () => this.close());
  },
  open(columnId, card=null) {
    this.activeCol = columnId;
    this.editingCard = card;
    this.head.textContent = card ? 'Editar tarjeta' : 'Nueva tarjeta';
    this.title.value = card ? card.title       : '';
    this.color.value = card ? card.color       : '#90caf9';
    this.desc.value  = card ? card.description : '';
    this.modal.classList.remove('hidden');
    this.title.focus();
  },
  close() {
    this.modal.classList.add('hidden');
    this.editingCard = null;
  },
  onSubmit(e) {
    e.preventDefault();
    const data = {
      title: this.title.value.trim(),
      color: this.color.value,
      description: this.desc.value.trim()
    };
    if (!data.title) return;

    if (this.editingCard) {
      CardService.update(this.editingCard, data);
    } else {
      CardService.create(this.activeCol, data);
    }

    StorageService.save(AppState.state);
    this.close();
    Renderer.renderBoard();
  }
};
