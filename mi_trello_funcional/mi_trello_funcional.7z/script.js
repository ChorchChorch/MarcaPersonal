// Estado global
let state = { columns: [], cards: [] };
let draggedId = null;
let activeColumnId = null;
let editingCard = null;

// DOM
const board = document.getElementById('board');
const modal = document.getElementById('card-modal');
const form = document.getElementById('card-form');
const modalTitle = document.getElementById('modal-title');
const inputTitle = document.getElementById('card-title');
const inputColor = document.getElementById('card-color');
const inputDesc = document.getElementById('card-description');
const btnCancel = document.getElementById('card-cancel');

// Inicializa o carga estado
function loadState() {
  const saved = localStorage.getItem('trello-mvp-state');
  if (saved) {
    state = JSON.parse(saved);
  } else {
    // Cinco columnas iniciales
    state.columns = [
      { id: 1, name: '1' },
      { id: 2, name: '2' },
      { id: 3, name: '3' },
      { id: 4, name: '4' },
      { id: 5, name: '5' }
    ];
    state.cards = [];
  }
}

function saveState() {
  localStorage.setItem('trello-mvp-state', JSON.stringify(state));
}

// Render de todo el tablero
function render() {
  board.innerHTML = '';
  state.columns.forEach(col => {
    const colEl = document.createElement('div');
    colEl.className = 'column';

    // Header con nombre y botón de editar
    const header = document.createElement('div');
    header.className = 'column-header';
    const title = document.createElement('span');
    title.textContent = col.name;
    const editBtn = document.createElement('button');
    editBtn.textContent = '✎';
    editBtn.title = 'Renombrar columna';
    editBtn.onclick = () => renameColumn(col.id);
    header.append(title, editBtn);
    colEl.append(header);

    // Zona de drop
    const cardsEl = document.createElement('div');
    cardsEl.className = 'cards';
    cardsEl.ondragover = e => e.preventDefault();
    cardsEl.ondrop = e => {
      e.preventDefault();
      const card = state.cards.find(c => c.id === draggedId);
      card.columnId = col.id;
      saveState();
      render();
    };

    // Render de tarjetas
    state.cards
      .filter(c => c.columnId === col.id)
      .forEach(c => {
        const el = document.createElement('div');
        el.className = 'card';
        el.draggable = true;
        el.style.borderColor = c.color;
        el.dataset.id = c.id;
        el.ondragstart = () => { draggedId = c.id; };

        const ch = document.createElement('div');
        ch.className = 'card-header';
        const span = document.createElement('span');
        span.textContent = c.title;
        const acts = document.createElement('div');
        const eb = document.createElement('button');
        eb.textContent = '✎'; eb.onclick = () => openModal(col.id, c);
        const db = document.createElement('button');
        db.textContent = '🗑'; db.onclick = () => deleteCard(c.id);
        acts.append(eb, db);

        ch.append(span, acts);
        const desc = document.createElement('div');
        desc.innerHTML = linkify(c.description);

        el.append(ch, desc);
        cardsEl.append(el);
      });

    colEl.append(cardsEl);

    // Botón crear tarjeta
    const add = document.createElement('div');
    add.className = 'add-card';
    add.textContent = '+ Carta';
    add.onclick = () => openModal(col.id);
    colEl.append(add);

    board.append(colEl);
  });
}

// Renombrar columna
function renameColumn(colId) {
  const col = state.columns.find(c => c.id === colId);
  const name = prompt('Nuevo nombre de columna:', col.name);
  if (name) {
    col.name = name.trim();
    saveState();
    render();
  }
}

// Modal: abrir/cerrar
function openModal(columnId, card = null) {
  activeColumnId = columnId;
  editingCard = card;
  if (card) {
    modalTitle.textContent = 'Editar tarjeta';
    inputTitle.value = card.title;
    inputColor.value = card.color;
    inputDesc.value = card.description;
  } else {
    modalTitle.textContent = 'Nueva tarjeta';
    inputTitle.value = '';
    inputColor.value = '#90caf9';
    inputDesc.value = '';
  }
  modal.classList.remove('hidden');
  inputTitle.focus();
}

function closeModal() {
  modal.classList.add('hidden');
  editingCard = null;
}

// CRUD Tarjetas
function createCard(data) {
  state.cards.push({
    id: Date.now(),
    columnId: activeColumnId,
    title: data.title,
    color: data.color,
    description: data.description
  });
}

function updateCard(card, data) {
  card.title = data.title;
  card.color = data.color;
  card.description = data.description;
}

function deleteCard(id) {
  if (confirm('¿Borrar esta tarjeta?')) {
    state.cards = state.cards.filter(c => c.id !== id);
    saveState();
    render();
  }
}

// Formulario de tarjeta
form.addEventListener('submit', e => {
  e.preventDefault();
  const data = {
    title: inputTitle.value.trim(),
    color: inputColor.value,
    description: inputDesc.value.trim()
  };
  if (!data.title) return;

  if (editingCard) updateCard(editingCard, data);
