window.CardService = {
  create(columnId, data) {
    AppState.state.cards.push({
      id: Date.now(),
      columnId,
      ...data
    });
  },
  update(card, data) {
    Object.assign(card, data);
  },
  delete(id) {
    AppState.state.cards = AppState.state.cards.filter(c => c.id !== id);
  }
};
