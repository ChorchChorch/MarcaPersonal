README (Ayuda de uso)
Clona o descarga estos tres archivos (index.html, style.css, script.js) en la misma carpeta.

Abre index.html en un servidor local (p. ej. con npx http-server .) para evitar restricciones de navegador.

Completa cada sección del formulario con los datos de tu producto.

Haz clic en Generar Código.

Copia el resultado de Meta Tags Generadas en el <head> de tu página de producto.

Copia el Bloque JSON-LD Generado justo antes de </body> o dentro del <head>.

Valida tu página con la Herramienta de Rich Results de Google https://search.google.com/test/rich-results

¡Listo! Tendrás una optimización SEO avanzada para tus “Velas LED de Seguridad” (o cualquier otro artículo físico) con datos estructurados y rich snippets