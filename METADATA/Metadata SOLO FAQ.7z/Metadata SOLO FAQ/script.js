// Añade dinámicamente un par pregunta/respuesta
document.getElementById('add-faq-btn').addEventListener('click', addFAQField);

function addFAQField() {
  const container = document.getElementById('faq-container');
  const index = container.children.length + 1;

  const wrapper = document.createElement('div');
  wrapper.className = 'faq-pair';
  wrapper.innerHTML = `
    <label>
      Pregunta ${index}:
      <input type="text" class="faq-question" placeholder="¿Tu pregunta aquí?" required>
    </label>
    <label>
      Respuesta ${index}:
      <textarea class="faq-answer" rows="2" placeholder="Respuesta a la pregunta" required></textarea>
    </label>
    <hr>
  `;
  container.appendChild(wrapper);
}

// Genera meta tags, JSON-LD y FAQPage
document.getElementById('generate-btn').addEventListener('click', () => {
  // (aquí lees los campos de tus secciones 1–5,
  // igual que antes, y construyes 'metaTags' y 'jsonLd'...)

  // Para simplificar, supongamos que ya tienes:
  const metaTags   = '...';    // tu código previo
  const jsonLdMain = { /* tu JSON-LD principal */ };

  // Generar FAQPage JSON-LD
  const faqPairs = Array.from(document.querySelectorAll('.faq-pair')).map(div => {
    const question = div.querySelector('.faq-question').value.trim();
    const answer   = div.querySelector('.faq-answer').value.trim();
    return {
      "@type": "Question",
      "name": question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": answer
      }
    };
  });

  const jsonLdFAQ = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqPairs
  };

  // Mostrar resultados
  document.getElementById('meta-output').textContent   = metaTags;
  document.getElementById('jsonld-output').textContent = JSON.stringify(jsonLdMain, null, 2);
  document.getElementById('faq-output').textContent    = JSON.stringify(jsonLdFAQ,  null, 2);
});
