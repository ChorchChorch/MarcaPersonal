const data = {
  hero: {
    name: "Benzaquen Jorge A",
    title: "Ingeniero TI Generalista | Responsable de Área",
    email: "benzaquenjorge@gmail.com",
    location: "Argentina",
    image: "jorge.jpg"
  },
  about: {
    title: "Sobre Mí",
    description: "Profesional comprometido, flexible y orientado a resultados. Me motiva mejorar continuamente procesos y equipos. Trabajo con autonomía y foco en metas anuales. En 2023, impulsé iniciativas como DRM, VMS para contingencia y MDM. Colaboro en el comité de control de gastos, evaluación técnica de proyectos, selección de proveedores y compras. Actualmente refuerzo mi inglés (B1) y manejo portugués funcional. Responsable de tecnología en Aduana local y soporte transversal a otras áreas. Si deseas conocer más o colaborar, contáctame sin compromiso."
  },
  experience: [
    {
      company: "Randon Argentina S.A.",
      logo: "randon-logo.png",
      role: "Especialista en TI / Responsable de Tecnología",
      period: "2014 – Actualidad",
      tasks: [
        "Gestión de equipo (2–3 personas), tercerizados y planta.",
        "Presupuesto y comité de inversiones, desarrollo y gestión de proveedores.",
        "ERP Softland, SQL Server, BI, documentación y análisis de procesos.",
        "Descubrimiento de mejoras y planificación interna.",
        "Infraestructura On Premise y sistema de cámaras.",
        "Reporte a gerencia, alineación con políticas corporativas.",
        "Referente local NOC y SOC matricial. Guardias pasivas.",
        "Plan de continuidad operativa DRP."
      ]
    },
    {
      company: "Technology Information",
      logo: "",
      role: "Analista de TI – Technology Information",
      period: "2011 – 2014 · 3 años",
      tasks: [
        "Comencé como pasante, luego JR hasta ser Analista de TI.",
        "Soporte N1 y N2, contacto directo con usuarios finales.",
        "Mapeo de demandas, planificación de tiempos y recursos.",
        "Dimensionamiento para atender necesidades internas.",
        "Gestión de inventario y documentación técnica.",
        "Control de costos.",
        "Primeros pasos en administración de DataCenter On Premise."
      ]
    }
  ],
  projects: [
    {
      image: "toolbox.jpg",
      title: "IT Manager Toolbox",
      description: "Charla sobre herramientas aplicadas al desarrollo del área de TI, destacando casos reales, experiencias y proyectos con impacto técnico y organizacional."
    }
  ],
  education: {
    institution: "Universidad Nacional de Rosario (UNR)",
    degree: "Ingeniero Electrónico",
    average: "8.36",
    project: "Proyecto final enfocado en la mitigación de ataques volumétricos de denegación de servicio (DDoS).",
    languages: [
      "Inglés (B1)",
      "Portugués funcional"
    ]
  },
  footer: "© Jorge Benzaquen - 2025"
};

function renderCV(data) {
  const insertOrRemove = (id, content) => {
    const el = document.getElementById(id);
    if (content) {
      el.innerHTML = content;
    } else {
      el?.remove();
    }
  };

  insertOrRemove('hero', data.hero?.name ? `
    <img src="${data.hero.image}" alt="Foto de Jorge" class="profile-pic" />
    <h1>${data.hero.name}</h1>
    <p>${data.hero.title}</p>
    <p>Email: <a href="mailto:${data.hero.email}">${data.hero.email}</a></p>
    <p>${data.hero.location}</p>
  ` : '');

  insertOrRemove('about', data.about?.description ? `
    <h2>${data.about.title || 'Sobre Mí'}</h2>
    <p>${data.about.description}</p>
  ` : '');

  insertOrRemove('experience', Array.isArray(data.experience) && data.experience.length > 0 ? `
    <h2>Experiencia Laboral</h2>
    ${data.experience.map(job => `
      <div class="job">
        <div class="job-header-with-logo">
          ${job.logo ? `<img src="${job.logo}" alt="Logo ${job.company}" class="job-logo" />` : ''}
          <h3>${job.company}</h3>
        </div>
        <div class="job-header">
          <h4>${job.role}</h4>
          <span class="job-date">${job.period}</span>
        </div>
        <ul>${job.tasks.map(task => `<li>${task}</li>`).join('')}</ul>
      </div>
    `).join('')}
  ` : '');

  insertOrRemove('projects', Array.isArray(data.projects) && data.projects.length > 0 ? `
    <h2>Proyectos Destacados</h2>
    ${data.projects.map(p => `
      <div class="project-card">
        <img src="${p.image}" alt="${p.title}" />
        <h4>${p.title}</h4>
        <p>${p.description}</p>
      </div>
    `).join('')}
  ` : '');

  const ed = data.education;
  insertOrRemove('education', ed && (ed.institution || ed.project || ed.languages) ? `
    <h2>Formación y Conocimientos</h2>
    ${ed.institution ? `<p><strong>${ed.institution}</strong> — ${ed.degree} | Promedio: ${ed.average}</p>` : ''}
    ${ed.project ? `<p>${ed.project}</p>` : ''}
    ${ed.languages ? `<p><strong>Idiomas:</strong> ${ed.languages.join(', ')}</p>` : ''}
  ` : '');

  insertOrRemove('footer', data.footer ? `<p>${data.footer}</p>` : '');
}

document.addEventListener("DOMContentLoaded", () => renderCV(data));
