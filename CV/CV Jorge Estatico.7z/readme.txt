Prompt reutilizable para diseño CSS de un CV profesional

Quiero un archivo CSS completo para aplicar a una página HTML de currículum personal. 
Debe tener un diseño limpio, moderno y profesional. 

✅ Estética limpia y profesional
✅ Animación de entrada para el hero
✅ Efectos suaves al pasar el cursor
✅ Proyectos alineados correctamente (imagen a la izquierda, texto arriba y distribuido)
✅ Responsive para móviles c
✅ Sombras sutiles y pulidas
✅ Centrado del footer

Estas son las características que debe cumplir:

Usa una tipografía legible, como Roboto.
El fondo general debe ser claro y el contenido sobre tarjetas blancas con sombras sutiles.
El header del CV debe tener animación de entrada tipo "fade-in", con imagen de perfil circular centrada arriba, nombre grande y datos personales debajo.
Las secciones (about, experience, projects, education, footer) deben estar separadas visualmente, con buena jerarquía tipográfica y márgenes generosos.

En la sección de proyectos:
Cada proyecto debe tener un título (h3) como encabezado principal.
Debajo del título, debe mostrarse una imagen alineada a la izquierda con un tamaño máximo controlado.
Junto a la imagen (a la derecha), debe ir la descripción del proyecto, alineada desde arriba, distribuyéndose en altura junto al margen de la imagen.
Títulos deben tener transición de color en hover.
Las imágenes deben tener efecto de escala al pasar el cursor (hover).
El diseño debe ser 100% responsive: cuando la pantalla sea pequeña, las columnas deben apilarse verticalmente sin perder claridad.
El footer debe estar centrado, con fuente más pequeña y color secundario.



